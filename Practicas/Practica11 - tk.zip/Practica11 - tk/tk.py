#!/bin/bash
import tkinter as tki
def reverse(s): 
  str = "" 
  for i in s: 
    str = i + str
  return str
ventana=tki.Tk()
ventana.geometry("1280x720")
textBox=tki.Entry(ventana)
textBox.pack()
label=tki.Label(ventana)
label.pack()

def textToBox():
	text20=textBox.get()
	text20r=reverse(text20)
	label["text"]=text20r

button1=tki.Button(ventana,text="reverse", command=textToBox)
button1.pack()


ventana.mainloop()